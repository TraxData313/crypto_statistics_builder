import json

def lambda_handler(event, context):
    # - get the price:
    import cbpro, time, datetime
    public_client = cbpro.PublicClient()
    
    
    
    
    
    
    return_message = "Not set yet"
    return {
        'statusCode': 200,
        'body': json.dumps(return_message)
    }
